Como publicar no GitHub Pages:
1. Crie um repositório no GitHub com nome "emporio-pequi" ou outro de sua escolha.
2. Envie os arquivos deste pacote (index.html, style.css, script.js).
3. Vá em "Settings" > "Pages" > selecione a branch main e pasta root.
4. Pronto! O site estará online.

Exemplo de URL: https://seuusuario.github.io/emporio-pequi/
